function add_player(){
    var player_1 = document.getElementById("p1").value;
    var player_2 = document.getElementById("p2").value;
    
    localStorage.setItem("player 1 name",player_1);
    localStorage.setItem("player 2 name",player_2);

    window.location = "index2.html";
}